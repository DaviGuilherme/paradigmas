package org.example;

import org.example.ex1.ListaLigada;

public class Main {
    public static void main(String[] args) {
        ListaLigada lista = new ListaLigada();

        lista.insereNode(1);
        lista.insereNode(2);
        lista.insereNode(3);

        lista.exibe();
        System.out.println(lista.buscaNode(1));
        System.out.println(lista.removeNode(1));
        System.out.println(lista.buscaNode(1));
        lista.exibe();
        System.out.println(lista.buscaNode(2));
    }
}